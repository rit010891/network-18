import java.util.Random;

public class Check {

    public static void main(String[] args) {
        for (int i=0;i<1000;i++) {
            Random rand = new Random();
            int n = rand.nextInt(90000) + 10000;
            System.out.println("Random=" + n);
        }
    }
}
