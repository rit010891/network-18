package enums;

public enum Direction {
	UP, DOWN, LEFT, RIGHT
}
