package com.lata.global;

public class GlobalVar {
    public static String context;

    public GlobalVar(String context) {
        this.context = context;
    }

    public String getContext() {
        return this.context;
    }
}
