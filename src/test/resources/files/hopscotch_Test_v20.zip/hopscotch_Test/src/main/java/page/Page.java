package page;

import java.time.Duration;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.concurrent.ThreadLocalRandom;

import io.appium.java_client.MobileDriver;
import io.appium.java_client.PressesKeyCode;
import io.appium.java_client.android.AndroidKeyCode;
import org.apache.commons.lang3.RandomStringUtils;
import org.apache.log4j.Logger;
import agent.IAgent;
import central.Configuration;
import central.AppachhiCentral;
import control.Control;
import control.IControl;
import enums.Platform;
import org.openqa.selenium.Keys;
import pagedef.Identifier;
import pagedef.PageDef;

public abstract class Page implements IPage {
	protected static Logger logger = AppachhiCentral.getLogger();
	private Configuration config = null;
	private IAgent agent = null;
	private PageDef pageDef = null;
	private Platform platform = null;
	private Map<String, String> testData = null;

	public Page(Configuration config, IAgent agent, Map<String, String> testData) throws Exception {
		this.testData = testData;
		this.config = config;
		this.platform = config.getPlatform();
		pageDef = AppachhiCentral.INSTANCE.getPageDef(this.getClass().getSimpleName());
		this.agent = agent;
	}

	protected Configuration getConfig() {
		return this.config;
	}

	public IAgent getAgent() {
		return this.agent;
	}

	protected Map<String, String> getTestData() {
		return this.testData;
	}

	public IControl getControl(String name) throws Exception {
		return Control.createControl(this, name, getIdentifier(name));
	}

	public List<IControl> getControls(String name) throws Exception {
		return Control.createControls(this, name, getIdentifier(name));
	}

	@Override
	public void takeSnapShot() throws Exception {
		this.agent.takeSnapShot();
	}

	@Override
	public void swipeUp() throws Exception {
		this.agent.swipeUp();
	}

	@Override
	public void swipeUp(int count) throws Exception {
		this.agent.swipeUp(count);
	}

	@Override
	public void swipeDown() throws Exception {
		this.agent.swipeDown();
	}

	@Override
	public void swipeDown(int count) throws Exception {
		this.agent.swipeDown(count);
	}

	@Override
	public void goTo(String url) throws Exception {
		this.agent.goTo(url);
	}

	@Override
	public void goBack() throws Exception {
		this.agent.goBack();
	}

	@Override
	public void switchToNewWindow() throws Exception {
		this.agent.switchToNewWindow();
	}

	@Override
	public void switchToMainWindow() throws Exception {
		this.agent.switchToMainWindow();
	}

	@Override
	public void acceptAlert() throws Exception {
		this.agent.acceptAlert();
	}

	@Override
	public void scrollUp() throws Exception {
		this.agent.scrollUp();
	}

	@Override
	public void scrollUp(int count) throws Exception {
		this.agent.scrollUp(count);
	}

	@Override
	public void scrollDown() throws Exception {
		this.agent.scrollDown();
	}

	@Override
	public void scrollDown(int count) throws Exception {
		this.agent.scrollDown(count);
	}

	@Override
	public Platform getPlatform() {
		return this.platform;
	}

	@Override
	public Identifier getIdentifier(String name) {
		return this.pageDef.getIdentifier(this.platform, name);
	}

	@Override
	public void switchToNativeView() throws Exception {
		this.agent.switchToNativeView();
	}

	@Override
	public void switchToWebView() throws Exception {
		this.agent.switchToWebView();
	}

	@Override
	public void assertPageLoad() throws Exception {
		this.agent.assertPageLoad();
	}

	@Override
	public void swipeDownTillElement(String elementName) throws Exception {
		this.agent.swipeDownTillElement(elementName);
		String msg = String.format("Scrolling till element - ", elementName);
		try {
			logger.debug(msg);
			for (int i = 0; i < 50; i++) {
				try {
					getControl(elementName);
					break;
				} catch (Exception e) {
					this.getAgent().swipeDown();
				}

			}
			this.getAgent().takeConditionalSnapShot();
		} catch (Exception e) {
			logger.debug(String.format("Failure in %s", msg));
		}
	}

	public void androidWebView() throws Exception {
		if (this.getPlatform() == Platform.ANDROID) {
			this.getAgent().switchToWebView();
		}
	}

	public void androidNativeView() throws Exception {
		if (this.getPlatform() == Platform.ANDROID) {
			this.getAgent().switchToNativeView();
		}
	}

	public void relauchApp() throws Exception{
		this.getAgent().getMobileDriver().closeApp();
		this.getAgent().getMobileDriver().launchApp();
	}
	public void key() throws Exception {
		String mobileUDID =this.getAgent().getMobileDriver().getCapabilities().getCapability("udid").toString();
		String command = "adb -s "+mobileUDID+" shell input text \"1111\"";
		Runtime.getRuntime().exec(command);

	}
	public void enterCVV() throws Exception {
		String mobileUDID =this.getAgent().getMobileDriver().getCapabilities().getCapability("udid").toString();
		String command = "adb -s "+mobileUDID+ " shell input text \"111\"";
		Process result = Runtime.getRuntime().exec(command);
	}

	public String generateUserId() {
		String mailId = String.valueOf(Math.abs(Integer.parseInt(String.valueOf(("newUser" + new Date().getTime()).hashCode()))))+"@gmail.com";
		return mailId;
	}

	public String generateUserName() {
		String name= RandomStringUtils.randomAlphabetic(6);
		return name;
	}

	public Integer generateRandomNumber(){
		Random rand = new Random();
		int n = rand.nextInt(90000) + 10000;
		return n;
	}

}
