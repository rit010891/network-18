package testcore.pages;

import agent.IAgent;
import central.Configuration;
import control.IControl;
import org.testng.Assert;

import java.util.List;
import java.util.Map;

public class MomentsPage extends FullPage {
    public MomentsPage(Configuration conf, IAgent agent, Map<String, String> testData) throws Exception {
        super(conf, agent, testData);
        assertPageLoad();
    }

    public void imageMoments() throws Exception {
        for (int i = 0; i < 5; i++) {
            List<IControl> allImages = getControls("lstImageProducts");
            for (int j = 0; j < 3; j++) {
                allImages.get(j).click();
                isMomentImages();
                isUploaderNameDisplayed();
                isShareProductDisplayed();
                goBack();
            }
            swipeDown(3);
        }
    }

    public void isMomentImages() throws Exception {
        boolean result = getControl("imgMomentsProduct").isVisible();
        logger.info("Moments Image displayed is :" + result);
        Assert.assertTrue(result, "Moments image not displayed");
    }

    public void isUploaderNameDisplayed() throws Exception {
        boolean result = getControl("txtUploaderName").isVisible();
        logger.info("Uploader name is :" + getControl("txtUploaderName").getText());
        Assert.assertTrue(result, "Uploader name is not displayed");
    }

    public void isShareProductDisplayed() throws Exception {
        boolean result = getControl("txtShareMoments").isVisible();
        logger.info("Share Product option displayed is :" + getControl("txtShareMoments").getText());
        Assert.assertTrue(result, "Share product option is not displayed");
    }
}
