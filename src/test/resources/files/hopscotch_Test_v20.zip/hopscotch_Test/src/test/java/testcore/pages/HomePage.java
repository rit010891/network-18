package testcore.pages;

import agent.IAgent;
import central.Configuration;
import org.testng.Assert;

import java.util.Map;

public class HomePage extends FullPage {

    public HomePage(Configuration conf, IAgent agent, Map<String, String> testData) throws Exception {
        super(conf, agent, testData);
        assertPageLoad();
    }

    /**
     * Method to navigate from Home screen to Account
     */
    public AccountPage moveToAccount() throws Exception {
        getControl("icoAccount").click();
        return new AccountPage(getConfig(), getAgent(), getTestData());
    }

    /**
     * Scroll down till the last product
     */
    public HomePage scrollDownHomePage() throws Exception {
        for(int i=0;i<10;i++){
            swipeDown(2);
        }
        return this;
    }

    /**
     * Navigating to Boutique list
     */
    public ProductListPage moveToBoutique() throws Exception {
        getControl("imgHomeBoutique").click();
        getControl("imgBoutique").click();
        return new ProductListPage(getConfig(), getAgent(), getTestData());
    }
    public ProductListPage navigateToBoutique() throws Exception {
        getControl("imgHomeBoutique").click();
        return new ProductListPage(getConfig(), getAgent(), getTestData());
    }

    /**
     * Navigating to Home screen after installation
     */
    public HomePage splashToHome() throws Exception {
        getControl("icnGender").click();
        handleAllowPermission();
        getControl("btnAge").click();
        handleAllowPermission();
        getControl("txtCoachMask").click();
        return this;
    }

    public void handleAllowPermission() throws Exception {
        boolean present = (getControls("btnAllowPermission").size() == 1);
        if (present) {
            getControl("btnAllowPermission").click();
            goBack();
        }
    }

    /**
     * Close existing session and relaunching app
     */
    public HomePage closeAndRelaunch() throws Exception {
        relauchApp();
       // getControl("icnGender").waitUntilVisible();
      //  splashToHome();
        return new HomePage(getConfig(), getAgent(), getTestData());
    }

    /**
     * Method to Search
     * Search parameter taken from ini file
     */
    public ProductListPage searchProduct() throws Exception {
        getControl("icoSearch").click();
        getControl("txtSearchHopscotch").click();
        getControl("txtEditSearchHopscotch").enterText(getTestData().get("SearchText"));
        getControl("txtSearchResult").click();
        return new ProductListPage(getConfig(), getAgent(), getTestData());
    }

    public void verifyAppRelaunched() throws Exception {
        //getControl("txtHomePageTitle").waitUntilVisible();
       // boolean result = (getControl("txtHomePageTitle").getText()).equalsIgnoreCase("Discover");
        getControl("icnGender").waitUntilVisible();
       boolean result = (getControl("txtHomePageTitle").getText()).equalsIgnoreCase("Discover");

        logger.info("App relauched is:" + getControl("icnGender").isVisible());
        Assert.assertTrue(result, "App not launched");
    }

    public CartPage moveToCart() throws Exception {
        getControl("icoCart").click();
        return new CartPage(getConfig(), getAgent(), getTestData());
    }

    public MomentsPage navigateToMoments() throws Exception {
        getControl("icoMoments").click();
        return new MomentsPage(getConfig(), getAgent(), getTestData());
    }
}
