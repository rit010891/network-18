package testcore.pages;

import agent.IAgent;
import central.Configuration;
import org.testng.Assert;

import java.util.Map;

public class AccountPage extends FullPage {
    public AccountPage(Configuration conf, IAgent agent, Map<String, String> testData) throws Exception {
        super(conf, agent, testData);
        assertPageLoad();
    }

    String userId = null;
    String mobileNumber = null;

    /**
     * Method to Login
     *
     * @return
     * @throws Exception
     */
    public AccountPage signIn() throws Exception {
        getControl("btnSignIn").click();
        getControl("txtEditMobileNumber").click();
        getControl("txtEditMobileNumber").enterText(getTestData().get("MobileNumber"));
        getControl("btnSendOTP").click();
        enterOTP();
        return this;
    }
    public AccountPage clearCart() throws Exception {
        getControl("icoCart").click();
        if(!getControl("icnProductEditInCart").isVisible()){
            getControl("icnProductEditInCart").click();
            getControl("txtRemoveFromCart").click();
            getControl("txtConfirmEditCart").click();
        }
        return this;
    }

    /**
     * Method for New Registration
     *
     * @return
     * @throws Exception
     */
    public AccountPage register() throws Exception {
        getControl("txtFullName").click();
        getControl("txtEditFullName").enterText(getTestData().get("FullName"));
        userId = generateUserId();
        getControl("txtEmailAddress").enterText(userId);
        mobileNumber = "11111" + generateRandomNumber().toString();
        getControl("txtMobileNumber").enterText(mobileNumber);
        getAgent().getMobileDriver()
                  .hideKeyboard();
        getControl("btnSendOTP").click();
        enterOTP();
        return this;
    }

    public AccountPage registerJoinUS() throws Exception {
        getControl("txtFullNameRegister").click();
        getControl("txtEditFullNameRegister").enterText(getTestData().get("FullName"));
        userId = generateUserId();
        getControl("txtEmailAddressRegister").enterText(userId);
        mobileNumber = "11111" + generateRandomNumber().toString();
        getControl("txtMobileNumberRegister").enterText(mobileNumber);
        getAgent().getMobileDriver()
                  .hideKeyboard();
        getControl("btnSendOTPRegister").click();
        enterOTP();
        return this;
    }

    /**
     * Method to View Profile Details
     *
     * @return
     * @throws Exception
     */
    public AccountPage profileDetails() throws Exception {
        getControl("btnProfileDetails").click();
        verifyProfileDetails();
        return this;
    }

    public AccountPage profileDetailsSignIn() throws Exception {
        getControl("btnProfileDetails").click();
        verifyProfileDetailsSignIn();
        return this;
    }

    public AccountPage editProfileName() throws Exception {
        getControl("txtEditProfileName").click();
        getControl("txtEditProfileFullName").clear();
        String editName=generateUserName();
        getControl("txtEditProfileFullName").enterText(editName);
        getControl("btnSaveEditFullName").click();
        verifyEditedUserName(editName);
        return this;
    }

    /**
     * Navigate to Cart
     *
     * @return
     * @throws Exception
     */
    public CartPage navigateToCart() throws Exception {
        getControl("icoCart").click();
        return new CartPage(getConfig(), getAgent(), getTestData());
    }

    /**
     * Assert
     */
    public AccountPage verifyProfileDetails() throws Exception {
        verifyUserName();
        verifyMobileNumber();
        verifyEmail();
        return this;
    }

    public AccountPage verifyProfileDetailsSignIn() throws Exception {
        verifyUserName();
        verifyMobileNumberSignIn();
        return this;
    }

    public void verifyUserName() throws Exception {
        boolean result = (getControl("txtUserName").getText()).equalsIgnoreCase(getTestData().get("FullName"));
        logger.info("Name displayed is:" + getControl("txtUserName").getText());
        Assert.assertTrue(result, "InCorrect name is displayed");
    }

    public void verifyMobileNumber() throws Exception {
        boolean result = (getControl("txtMobileNumberVerify").getText()).equalsIgnoreCase(mobileNumber);
        logger.info("Mobile number displayed is:" + getControl("txtMobileNumberVerify").getText());
        Assert.assertTrue(result, "InCorrect mobile number is displayed");

    }

    public void verifyEmail() throws Exception {
        boolean result = (getControl("txtEmail").getText()).equalsIgnoreCase(userId);
        logger.info("mail id displayed is:" + getControl("txtEmail").getText());
        Assert.assertTrue(result, "InCorrect mail id is displayed");
    }

    public void verifyMobileNumberSignIn() throws Exception {
        boolean result = (getControl("txtMobileNumberVerify").getText()).equalsIgnoreCase(getTestData().get("MobileNumber"));
        logger.info("Mobile number displayed is:" + getControl("txtMobileNumberVerify").getText());
        Assert.assertTrue(result, "InCorrect mobile number is displayed");

    }

    public void verifyEditedUserName(String name) throws Exception {
        boolean result = (getControl("txtEditProfileName").getText()).equalsIgnoreCase(name);
        logger.info("Name displayed after update is:" + getControl("txtEditProfileName").getText());
        Assert.assertTrue(result, "InCorrect name is displayed");
    }

    public HomePage navigateToSearch() throws Exception {
        getControl("icoSearch").click();
        return new HomePage(getConfig(), getAgent(), getTestData());
    }

    public AccountPage registerUsingJoinUs() throws Exception {
        getControl("btnSignIn").click();
        getControl("lnkJoinUsSignIn").click();
        getControl("txtFullName").click();
        getControl("txtEditFullName").enterText(getTestData().get("FullName"));
        userId = generateUserId();
        getControl("txtEmailAddress").enterText(userId);
        mobileNumber = "11111" + generateRandomNumber().toString();
        getControl("txtMobileNumber").enterText(mobileNumber);
        getAgent().getMobileDriver()
                .hideKeyboard();
        getControl("btnSendOTPRegister").click();
        enterOTP();
        return this;
    }

    public AccountPage joinUs() throws Exception {
        getControl("lnkJoinUs").click();
        registerJoinUS();
        return this;
    }

    public AccountPage enterOTP() throws Exception {
        key();
        return this;
    }

    public AddressPage savedAddresses() throws Exception {
        getControl("btnSavedAddresses").click();
        verifyProfileDetails();
        return new AddressPage(getConfig(), getAgent(), getTestData());
    }

    public AccountPage newMobileNumberJoinUs() throws Exception {
        getControl("btnSignIn").click();
        getControl("lnkJoinUsSignIn").click();
        enterNewMobileNumberJoinUs();
        return this;
    }

    public AccountPage joinUSRegister() throws Exception {
        getControl("btnSignIn").click();
        getControl("lnkJoinUsSignIn").click();
        registerJoinUS();
        return this;
    }

    public AccountPage enterNewMobileNumberJoinUs() throws Exception {
        getControl("txtFullNameNew").click();
        getControl("txtEditFullNameNew").enterText(getTestData().get("FullNameNew"));
        getControl("txtEditEmailAddressNew").enterText(getTestData().get("EmailAddressNew"));
        getControl("txtMobileNumberNew").click();
        mobileNumber = "11111" + generateRandomNumber().toString();
        getControl("txtEditMobileNumberNew").enterText(mobileNumber);
        getAgent().getMobileDriver()
                  .hideKeyboard();
        getControl("btnSendOTP").click();
        enterOTP();
        return this;
    }

    public AccountPage isUserLoggedIn() throws Exception {
        getControl("icoAccount").click();
        getControl("btnProfileDetails").click();
        boolean result = (getControl("txtUserName").getText()).equalsIgnoreCase(getTestData().get("FullName"));
        logger.info("User logged in: " + getControl("txtUserName").isVisible());
        logger.info("Logged in user is: " + getControl("txtUserName").getText());
        Assert.assertTrue(result, "User not logged in");
        return this;
    }
}
