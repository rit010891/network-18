package testcore.pages;

import agent.IAgent;
import central.Configuration;

import java.util.Map;

public class AddressPage extends FullPage {
    public AddressPage(Configuration conf, IAgent agent, Map<String, String> testData) throws Exception {
        super(conf, agent, testData);
        assertPageLoad();
    }

    String userId = null;
    String mobileNumber = null;

    public PaymentPage shipToNewAddress() throws Exception {
        getControl("txtFullName").click();
        getControl("txtEditFullName").enterText(getTestData().get("FullName"));
        getControl("txtPincode").enterText(getTestData().get("Pincode"));
        getControl("txtAddress").enterText(getTestData().get("Address"));
        getControl("txtLandmark").enterText(getTestData().get("Landmark"));
        getAgent().getMobileDriver()
                  .hideKeyboard();
        getControl("btnContinue").click();
        return new PaymentPage(getConfig(), getAgent(), getTestData());
    }

    public PaymentPage shipToExistingAddress() throws Exception {
        getControl("txtShipToExistingAddress").click();
        getControl("btnContinue").click();
        getControl("btnPay").click();
        return new PaymentPage(getConfig(), getAgent(), getTestData());
    }

    public PaymentPage existingAddressInvalidCard() throws Exception {
        getControl("txtShipToExistingAddress").click();
        getControl("btnContinue").click();
        getControl("btnPayBy").click();
        return new PaymentPage(getConfig(), getAgent(), getTestData());
    }

    public PaymentPage enterMobileNumber() throws Exception {
        getControl("txtMobileNumberGuest").click();
        getControl("txtMobileNumberGuest").enterText(getTestData().get("MobileNumber"));
        getControl("btnContinue").click();
        getControl("btnSignIn").click();
        key();
        getControl("btnSavedAddressesContinue").click();
        return new PaymentPage(getConfig(), getAgent(), getTestData());
    }

    public PaymentPage guestAddAddress() throws Exception {
        mobileNumber = "11111" + generateRandomNumber().toString();
        getControl("txtMobileNumberGuest").enterText(mobileNumber);
        logger.info(String.format("Mobile number entered is %s " , mobileNumber));
        getControl("btnContinue").click();
        shipToNewAddressGuest();
        return new PaymentPage(getConfig(), getAgent(), getTestData());
    }

    public PaymentPage shipToNewAddressGuest() throws Exception {
        getControl("txtEditFullNameGuest").enterText(getTestData().get("FullName"));
        getControl("txtPincodeGuest").enterText(getTestData().get("Pincode"));
        getControl("txtAddressGuest").enterText(getTestData().get("Address"));
        getControl("txtClickLandmarkGuest").click();
        getControl("txtLandmarkGuest").enterText(getTestData().get("Landmark"));
        getAgent().getMobileDriver()
                  .hideKeyboard();
        getControl("txtEmailGuest").click();
        userId = generateUserId();
        getControl("txtEditEmailAddressGuest").enterText(userId);
        swipeDown(1);
        getAgent().getMobileDriver()
                  .hideKeyboard();
        getControl("btnGuestContinue").click();
        return new PaymentPage(getConfig(), getAgent(), getTestData());
    }
    public PaymentPage shipToNewAddressPromoCode() throws Exception {
        getControl("txtEditFullNamePromo").enterText(getTestData().get("FullName"));
        getControl("txtPincodePromo").enterText(getTestData().get("Pincode"));
        getControl("txtAddressPromo").enterText(getTestData().get("Address"));
        getControl("txtClickLandmarkPromo").click();
        getControl("txtLandmarkPromo").enterText(getTestData().get("Landmark"));
        getAgent().getMobileDriver()
                  .hideKeyboard();
        getControl("txtEmailPromo").click();
        userId = generateUserId();
        getControl("txtEditEmailAddressPromo").enterText(userId);
        swipeDown(1);
        getAgent().getMobileDriver()
                  .hideKeyboard();
        getControl("btnPromoContinue").click();
        return new PaymentPage(getConfig(), getAgent(), getTestData());
    }

    public AddressPage signInSavedAddress() throws Exception {
        getControl("btnSignIn").click();
        key();
        getControl("btnContinue").click();
        return this;
    }

    public PaymentPage promoCodeCOD() throws Exception {
        getControl("txtPayBy").click();
        getControl("txtCashOnDelivery").click();
        getControl("btnPlaceOrder").click();
        return new PaymentPage(getConfig(), getAgent(), getTestData());
    }

    public AddressPage newMobileNumber() throws Exception{
        getControl("txtMobileNumberGuest").click();
        mobileNumber = "11111" + generateRandomNumber().toString();
        getControl("txtMobileNumberGuest").enterText("5485694121");
        logger.info(String.format("Mobile number entered is %s " , mobileNumber));
        getControl("btnContinue").click();
        return this;
    }
    public AddressPage newAddressExistingMailID() throws Exception {
        getControl("txtEditFullNameGuest").enterText(getTestData().get("FullName"));
        getControl("txtPincodeGuest").enterText(getTestData().get("Pincode"));
        getControl("txtAddressGuest").enterText(getTestData().get("Address"));
        getControl("txtClickLandmarkGuest").click();
        getControl("txtLandmarkGuest").enterText(getTestData().get("Landmark"));
        getAgent().getMobileDriver()
                  .hideKeyboard();
        getControl("txtEmailGuest").click();;
        getControl("txtEditEmailAddressGuest").enterText(getTestData().get("EmailAddress"));
        swipeDown(1);
        getAgent().getMobileDriver()
                  .hideKeyboard();
        getControl("btnGuestContinue").click();
        return this;
    }
    public AccountPage signInFromAccount()throws Exception {
        getControl("txtSignInFromAccount").click();
        swipeDownTillElement("btnSignIn");
        getControl("btnSignIn").click();
        getControl("lnkSignInFromMail").click();
        getControl("txtEmail").enterText(getTestData().get("EmailAddress"));
        getControl("txtPassword").enterText(getTestData().get("Password"));
        getControl("btnSignIn").click();
        return new AccountPage(getConfig(),getAgent(),getTestData());
    }
}

