package testcore.pages;

import agent.IAgent;
import central.Configuration;
import control.IControl;
import org.testng.Assert;

import java.util.List;
import java.util.Map;

public class ProductDescPage extends FullPage {
    public ProductDescPage(Configuration conf, IAgent agent, Map<String, String> testData) throws Exception {
        super(conf, agent, testData);
        assertPageLoad();
    }

    /**
     * Method to add multiple products by selecting age
     */
    public ProductListPage addToCart() throws Exception {
        getControl("btnSelectSize").click();
        addAvailableProductToCart();
        return new ProductListPage(getConfig(), getAgent(), getTestData());
    }

    /**
     * Method to add multiple products by selecting age
     */
    public CartPage multipleItemsAddToCart() throws Exception {
        getControl("btnSelectSize").click();
        addMultipleProductToCart();
        getControl("btnQuantity").click();
        swipeDown(2);
        getControl("btnAddToCart").click();
        moveToCart();
        return new CartPage(getConfig(), getAgent(), getTestData());
    }

    /**
     * Scroll till Similar product text is visible
     */
    public ProductDescPage similarProducts() throws Exception {
        swipeDownTillElement("lblSimilarProduct");
        return this;
    }

    /**
     * Scroll till Similar product text and adding it to cart
     */
    public ProductDescPage viewSimilarProducts() throws Exception {
        for (int i = 0; i < 5; i++) {
            similarProducts();
            getControl("imgFirstSimilarProduct").click();
            isSimilarProductDisplayed();
        }
        return this;
    }

    public ProductListPage moveToCart() throws Exception {
        getControl("icoCart").click();
        return new ProductListPage(getConfig(), getAgent(), getTestData());
    }

    /**
     * Assertion
     *
     * @throws Exception
     */
    public void isAbleToScroll() throws Exception {
        boolean isProductsdisplayed = getControl("imgMidProduct").isVisible();
        Assert.assertEquals(true, isProductsdisplayed);
    }


    public ProductDescPage selectLastProduct() throws Exception {
        getControl("txtLastProductName").click();
        return this;
    }

    public void isProductImageDetailsDisplayed() throws Exception {
        isProductImageDisplayed();
        isProductDetailsDisplayed();
        isSimilarProductDisplayed();
    }

    public void isSimilarProductDisplayed() throws Exception {
        swipeDownTillElement("lblSimilarProduct");
        boolean isProductDisplayed = getControl("lblSimilarProduct").isVisible();
        logger.info("Similar Product is:" + getControl("lblSimilarProduct").isVisible());
        Assert.assertTrue(isProductDisplayed, "Similar products not displayed");
    }

    public void isProductImageDisplayed() throws Exception {
        boolean isProductDisplayed = getControl("imgProduct").isVisible();
        logger.info("Product image is:" + getControl("imgProduct").isVisible());
        Assert.assertTrue(isProductDisplayed, "Product image not displayed");
    }

    public void isProductDetailsDisplayed() throws Exception {
        boolean isProductDisplayed = getControl("txtProductDetails").isVisible();
        logger.info("Product detail is:" + getControl("txtProductDetails").getText());
        Assert.assertTrue(isProductDisplayed, "Product details not displayed");
    }

    public void validatePincode() throws Exception {
        swipeDownTillElement("txtCheckPincode");
        getControl("txtCheckPincode").click();
        getAgent().getMobileDriver()
                  .getKeyboard()
                  .sendKeys(getTestData().get("Pincode"));
        getControl("txtConfirm").click();
        isEstimatedDeliveryDateDisplayed();
    }

    public void isEstimatedDeliveryDateDisplayed() throws Exception {
        boolean isEDDDisplayed = getControl("txtEDD").isVisible();
        logger.info("Estimated Delivery Date is:" + getControl("txtEDD").getText());
        Assert.assertTrue(isEDDDisplayed, "Estimated Delivery Date is not displayed");
    }

    public void addAvailableProductToCart() throws Exception {
        List<IControl> availableSize = getControls("lstSize");
        logger.info("available sizes "+availableSize.size());
        for (int i = 0; i < availableSize.size(); i++) {
            availableSize.get(i).click();
            if(!getControl("btnNotifyMe").getText().equalsIgnoreCase("NOTIFY ME")){
                getControl("btnAddToCart").click();
                break;
            }
        }
    }
    public void addMultipleProductToCart() throws Exception {
        List<IControl> availableSize = getControls("lstSize");
        logger.info("available sizes "+availableSize.size());
        for (int i = 0; i < availableSize.size(); i++) {
            availableSize.get(i).click();
            if(!getControl("btnNotifyMe").getText().equalsIgnoreCase("NOTIFY ME")){
                break;
            }
        }
    }
}
