package testcore.pages;

import agent.IAgent;
import central.Configuration;
import org.testng.Assert;

import java.util.Map;

public class ProductListPage extends FullPage {
    public ProductListPage(Configuration conf, IAgent agent, Map<String, String> testData) throws Exception {
        super(conf, agent, testData);
        assertPageLoad();
    }

    /**
     * Selecting first product and navigating to description page from list page
     */
    public ProductDescPage searchListToDesc() throws Exception {
        getControl("imgSearchProductLink").click();
        return new ProductDescPage(getConfig(), getAgent(), getTestData());
    }

    public ProductDescPage boutiqueListToDesc() throws Exception {
        getControl("imgProductLink").click();
        return new ProductDescPage(getConfig(), getAgent(), getTestData());
    }

    /**
     * Selecting the last product from the list
     */

    public ProductDescPage swipeTillLastProduct() throws Exception {
        int swipeCount = 0;
        int maxSwipeCount = 30;
        swipeDown(2);
        while (!isLastProductVisible() && (swipeCount < maxSwipeCount)) {
            swipeDown(4);
            swipeCount++;
        }
        return new ProductDescPage(getConfig(), getAgent(), getTestData());
    }

    public ProductDescPage swipeTillSearchLastProduct() throws Exception {
        swipeDown(2);
        int swipeCount = 0;
        int maxSwipeCount = 30;
        while (!isSearchLastProductVisible() && (swipeCount < maxSwipeCount)) {
            swipeDown(4);
            swipeCount++;
        }
        return new ProductDescPage(getConfig(), getAgent(), getTestData());
    }

    protected boolean isLastProductVisible() throws Exception {
        String val = getControl("txtLastProduct").getText();
        String[] counts = val.split("of");
        String presentCount = counts[0].trim();
        logger.info("the count of present count is " + presentCount);
        String endCount = counts[1].trim()
                                   .split("products", 0)[0].trim();
        logger.info("the count of end count is " + endCount);
        boolean lastProductAvailable = presentCount.equalsIgnoreCase(endCount);
        return lastProductAvailable;
    }

    protected void availableProductCounts()throws Exception{
        String val = getControl("txtLastProduct").getText();
        String[] counts = val.split("of");
        String endCount = counts[1].trim()
                .split("products", 0)[0].trim();
        boolean result = (getControl("txtProductName").isVisible());
        logger.info("Products are displayed:" + getControl("txtProductName").isVisible());
        logger.info("Total product count is " + endCount);
        Assert.assertTrue(result, "Products are not displayed");
    }

    protected boolean isSearchLastProductVisible() throws Exception {
        String val = getControl("txtSearchLastProduct").getText();
        String[] counts = val.split("of");
        String presentCount = counts[0].trim();
        String endCount = counts[1].trim()
                                   .split("products", 0)[0].trim();
        boolean lastProductAvailable = presentCount.equalsIgnoreCase(endCount);
        return lastProductAvailable;
    }

    /**
     * Verifying Boutique after navigating back from product list
     */
    public ProductListPage verifyBoutique() throws Exception {
        for(int i=0; i<10; i++){
            getControl("imgBoutique").click();
            swipeDown(2);
            availableProductCounts();
            goBack();
            swipeDown(2);
        }
        return this;
    }




    /**
     * Navigating Back to Home screen from Product List page
     */
    public HomePage goBackToHome() throws Exception {
        goBack();
        return new HomePage(getConfig(), getAgent(), getTestData());
    }

    /**
     * Assertion
     *
     * @throws Exception
     */

    public void isAbleToScroll() throws Exception {
        swipeTillSearchLastProduct();
        boolean isProductdisplayed = getControl("imgSearchProductLink").isVisible();
        logger.info("Able to scroll down:" + getControl("imgSearchProductLink").isVisible());
        logger.info("Able to scroll down:" + getControl("imgSearchProductLink").getText());
        Assert.assertTrue(isProductdisplayed, "Not able to scroll");
    }

    public ProductListPage applyAllFilter() throws Exception {
        //applyShopForFilter();
        applyAgeFilter();
        applyCategoryFilter();
        applyDeliveryTimeFilter();
        applyBrandsFilter();
        applyColourFilter();
        applyPriceFilter();
        applyDiscountFilter();
        return this;
    }

    public void validateFilterOptions() throws Exception {
        boolean result = getControl("lstFilteredProduct").isVisible();
        logger.info("List view displayed is :" + result);
        Assert.assertTrue(result, "Filtered list view is not displayed");
    }

    public ProductListPage applyShopForFilter() throws Exception {
        getControl("txtFilter").click();
        getControl("txtFilterShopFor").click();
        logger.info("Filter is:" + getControl("txtFilterShopFor").getText());
        verifySubFilter();
        return this;
    }

    public ProductListPage applyAgeFilter() throws Exception {
        getControl("txtFilter").click();
        getControl("txtFilterAge").click();
        logger.info("Filter is:" + getControl("txtFilterAge").getText());
        verifySubFilter();
        return this;
    }

    public ProductListPage applyCategoryFilter() throws Exception {
        getControl("txtFilter").click();
        getControl("btnClearAll").click();
        getControl("txtFilterCategory").click();
        logger.info("Filter is:" + getControl("txtFilterCategory").getText());
        verifySubFilter();
        return this;
    }

    public ProductListPage applyDeliveryTimeFilter() throws Exception {
        getControl("txtFilter").click();
        getControl("txtFilterDeliveryTime").click();
        logger.info("Filter is:" + getControl("txtFilterDeliveryTime").getText());
        verifySubFilter();
        return this;
    }

    public ProductListPage applyBrandsFilter() throws Exception {
        getControl("txtFilter").click();
        getControl("btnClearAll").click();
        getControl("txtFilterBrands").click();
        logger.info("Filter is:" + getControl("txtFilterBrands").getText());
        verifySubFilter();
        return this;
    }

    public ProductListPage applyColourFilter() throws Exception {
        getControl("txtFilter").click();
        getControl("btnClearAll").click();
        getControl("txtFilterColour").click();
        logger.info("Filter is:" + getControl("txtFilterColour").getText());
        verifySubFilter();
        return this;
    }

    public ProductListPage applyPriceFilter() throws Exception {
        getControl("txtFilter").click();
        getControl("btnClearAll").click();
        getControl("txtFilterPrice").click();
        logger.info("Filter is:" + getControl("txtFilterPrice").getText());
        verifySubFilter();
        return this;
    }

    public ProductListPage applyDiscountFilter() throws Exception {
        getControl("txtFilter").click();
        getControl("btnClearAll").click();
        getControl("txtFilterDiscount").click();
        logger.info("Filter is:" + getControl("txtFilterDiscount").getText());
        verifySubFilter();
        return this;
    }

    public void verifySubFilter() throws Exception {
        getControl("txtSubFilter").click();
        logger.info("SubFilter is:" + getControl("txtSubFilter").getText());
        getControl("btnApply").click();
        validateFilterOptions();
        getControl("txtFilter").click();
        goBack();
    }
}
