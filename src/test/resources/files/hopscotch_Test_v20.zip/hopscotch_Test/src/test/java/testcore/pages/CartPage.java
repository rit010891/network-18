package testcore.pages;

import agent.IAgent;
import central.Configuration;
import io.appium.java_client.TouchAction;
import org.openqa.selenium.Dimension;
import org.testng.Assert;

import java.awt.*;
import java.time.Duration;
import java.util.Map;

public class CartPage extends FullPage {

    public CartPage(Configuration conf, IAgent agent, Map<String, String> testData) throws Exception {
        super(conf, agent, testData);
        assertPageLoad();
    }

    String mobileNumber = null;

    public AddressPage navigateToCheckOut() throws Exception {
        getControl("btnCheckOut").click();
        return new AddressPage(getConfig(), getAgent(), getTestData());
    }

    public CartPage updateCart() throws Exception {
        getControl("btnUpdateCart").click();
        return this;
    }

    public CartPage notNowInCart() throws Exception {
        getControl("btnNotNow").click();
        return this;
    }

    public CartPage isCartEmpty() throws Exception {
        goBack();
        getControl("icoCart").click();
        logger.info(getControl("txtEmptyCart").getText());
        boolean result = getControl("txtEmptyCart").getText()
                                                         .equalsIgnoreCase("There's nothing in here ");
        logger.info("Cart contains:" + getControl("txtEmptyCart").getText());
        Assert.assertTrue(result, "Cart contains items");
        return this;
    }

    public HomePage shopNowForNextRun() throws Exception {
        getControl("btnShopNow").click();
        return new HomePage(getConfig(),getAgent(),getTestData());
    }


    public void isProductPresent() throws Exception {
        goBack();
        getControl("icoCart").click();
        boolean result = getControl("lblQuantity").isVisible();
        logger.info("Cart contains:" + getControl("lblQuantity").getText());
        Assert.assertTrue(result, "Cart does'nt have items");
    }

    public void isMultipleProductsAdded() throws Exception {
        boolean result = (getControl("lblQuantity").getText()).equalsIgnoreCase("10 items");
        logger.info("Product quantity is:" + getControl("lblQuantity").getText());
        if(result){
            Assert.assertTrue(result, "InCorrect quantity is displayed");
        }
        else{
            Assert.assertFalse(result, getControl("lblQuantity").getText()+"  added to cart");
        }
    }

    public CartPage cancelOrder() throws Exception {
        goBack();
        getControl("icoAccount").click();
        getControl("btnOrders").click();
        getControl("imgPlacedOrder").click();
        getControl("btnCancelItem").click();
        key();
        getControl("chkSelectCancelItem").click();
        getControl("txtSelectAReason").click();
        getControl("rdoOrderCancelReason").click();
        slideToCancel();
        return this;
    }

    public void slideToCancel() throws Exception{
        Dimension size = getAgent().getMobileDriver().manage().window().getSize();
        System.out.println(size);

        int startx = (int) (size.width * 0.10);
        int endx = (int) (size.width * 0.95);
        int starty = (int) (size.height * 0.95);
        System.out.println("startx = " + startx + " ,endx = " + endx + " , starty = " + starty);
//        TouchAction action = new TouchAction(getAgent().getMobileDriver());
        logger.info("swipe started");
//        action.longPress(startx, starty).moveTo(endx, starty).release().perform();
        new TouchAction(getAgent().getMobileDriver()).press(startx, starty).waitAction(Duration.ofMillis(1000))
                .moveTo(endx, starty).release().perform();
        logger.info("swipe ended");
    }

    public CartPage enterPromoCode() throws Exception {
        getControl("txtPromoCode").click();
        getControl("txtEnterPromoCode").enterText(getTestData().get("PromoCode"));
        getControl("txtApplyPromoCode").click();
        getControl("txtApplyPromoCode").click();
        return this;
    }

    public CartPage PromoCodeMobileNumber() throws Exception {
        getControl("txtPromoCode").click();
        getControl("txtEnterPromoCode").enterText(getTestData().get("PromoCode"));
        getControl("txtApplyPromoCode").click();
        getControl("txtApplyPromoCode").click();
        mobileNumber = "11111" + generateRandomNumber().toString();
        logger.info(mobileNumber);
        getControl("txtMobileNumberGuest").enterText(mobileNumber);
        getControl("txtSaveAndVerify").click();
        key();
        return this;
    }
    public PaymentPage incrementQuantity() throws Exception {
        getControl("icnProductEditInCart").click();
        getControl("txtChangeQuantity").click();
        logger.info("increment buttton "+getControl("icnIncreaseProduct").getText());
        getControl("icnIncreaseProduct").click();
        getControl("txtConfirmEditCart").click();
        getControl("btnCheckOut").click();
        return new PaymentPage(getConfig(),getAgent(),getTestData());
    }
    public void isOrderCancelled() throws Exception {
        boolean result = getControl("txtCancelOrder").getText().equalsIgnoreCase("1 item was cancelled successfully!");
        logger.info("Item cancelled" + getControl("txtCancelOrder").isVisible());
        Assert.assertTrue(result, "Unable to cancel the order");
    }
    public void orderPaymentFailed() throws Exception {
        boolean orderNotPlaced = getControl("txtRetryPayment").getText()
                .equalsIgnoreCase("Retry payment");
        logger.info("Order Status:" + getControl("txtRetryPayment").getText());
        Assert.assertTrue(orderNotPlaced, "Order placed");
    }
}
