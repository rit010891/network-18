package testcore.pages;

import agent.IAgent;
import central.Configuration;
import org.openqa.selenium.By;
import org.testng.Assert;

import java.util.Map;

public class PaymentPage extends FullPage {
    public PaymentPage(Configuration conf, IAgent agent, Map<String, String> testData) throws Exception {
        super(conf, agent, testData);
        assertPageLoad();
    }

    public PaymentPage cashOnDelivery() throws Exception {
        getControl("txtCashOnDelivery").click();
        getControl("btnPlaceOrder").click();
        return this;
    }

    public CartPage creditDebitCard() throws Exception {
        getControl("txtPayBy").click();
        enterCardDetails();
        isOrderPlaced();
        return new CartPage(getConfig(), getAgent(), getTestData());
    }

    public CartPage invalidCreditDebitCard() throws Exception {
        enterCardDetails();
        isErrorMessageDisplayed();
        return new CartPage (getConfig(), getAgent(), getTestData());
    }

    public PaymentPage enterCardDetails() throws Exception {
        getControl("txtCreditDebitCard").click();
        getControl("txtCardNumber").enterText(getTestData().get("CardNumber"));
        getControl("txtExpiryDate").enterText(getTestData().get("ExpiryDate"));
        getControl("txtCVV").enterText(getTestData().get("CVV"));
        getControl("txtNameOnCard").enterText(getTestData().get("NameOnCard"));
        getAgent().getMobileDriver()
                .hideKeyboard();
        getControl("btnContinue").waitUntilVisible();
        logger.info("Continue button enabled: "+getControl("btnContinue").getText() );
        logger.info("Clicking on Continue button");
        getControl("btnContinue").click();
        getControl("btnPay").waitUntilVisible();
        getControl("btnPay").click();
        return new PaymentPage(getConfig(), getAgent(), getTestData());
    }

    public void isOrderPlaced() throws Exception {
       // Thread.sleep(20000);
        waitTillPaymentProcesses();
        boolean orderConfirmation = getControl("txtOrderConfirmationMessage").getText()
                                                                            .equalsIgnoreCase("Your order has been confirmed");
        logger.info("Order Number is:" + getControl("txtOrderNumber").getText());
        logger.info("Ordered Product is:" + getControl("txtOrderedProduct").getText());
        Assert.assertTrue(orderConfirmation, "Order not placed");
    }

    public void isErrorMessageDisplayed() throws Exception {
        waitTillRetryPaymentProcesses();
        boolean orderNotPlaced = getControl("txtRetryPayment").getText()
                                                                    .equalsIgnoreCase("Retry payment");
        logger.info("Order Status:" + getControl("txtRetryPayment").getText());
        Assert.assertTrue(orderNotPlaced, "Order placed");
    }

    public AccountPage savedCardPayment() throws Exception {
        getControl("btnPay").click();
        enterCVV();
        logger.info("buy button "+getControl("btnPay").getText());
        getControl("btnPay").click();
        isOrderPlaced();
        goBack();
        return new AccountPage(getConfig(), getAgent(), getTestData());
    }

    public PaymentPage savedCardPaymentExistingUser() throws Exception {
        getControl("btnPlaceOrderExistingUser").click();
        isOrderPlaced();
        return this;
    }


    public void waitTillPaymentProcesses() throws Exception {
        for (int i = 0; i < 10; i++) {
            if (getControl("txtOrderConfirmation").isVisible()) {
                break;
            } else {
                getControl("txtOrderConfirmation").waitUntilVisible();
            }
        }
    }

    public void waitTillRetryPaymentProcesses() throws Exception {
        for (int i = 0; i < 10; i++) {
            if (getControl("txtRetryPayment").isVisible()) {
                break;
            } else {
                getControl("txtRetryPayment").waitUntilVisible();
            }
        }
    }

    public CartPage creditCardPayment() throws Exception {
        getControl("txtPayBy").click();
        enterCardDetails();
        isOrderPlaced();
        return new CartPage(getConfig(), getAgent(), getTestData());
    }

    public CartPage cancelOnReviewPage() throws Exception {
        goBack();
        goBack();
        checkoutCancel();
        return new CartPage(getConfig(), getAgent(), getTestData());
    }

    public PaymentPage checkoutCancel() throws Exception {
        getControl("txtCheckoutCancel").click();
        return this;
    }
}

