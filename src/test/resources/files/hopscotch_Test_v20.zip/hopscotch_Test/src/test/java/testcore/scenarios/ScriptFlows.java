package testcore.scenarios;

import org.testng.annotations.Test;

public class ScriptFlows extends SupportTest {

    @Test(groups = {"Hopscotch"},
          description = "HS_01",
          alwaysRun = true)
    public void HS_01() throws Exception {
        logger.debug(this.getTestStartInfoMessage("HS_01"));
        home.splashToHome()
            .moveToAccount()
            .joinUs()
            .profileDetails();
        logger.debug(this.getTestEndInfoMessage("HS_01"));
    }

    @Test(groups = {"Hopscotch"},
          description = "HS_02",
          alwaysRun = true)
    public void HS_02() throws Exception {
        logger.debug(this.getTestStartInfoMessage("HS_02"));
        home.splashToHome()
            .searchProduct()
            .searchListToDesc()
            .addToCart()
            .goBackToHome()
            .moveToAccount()
            .registerUsingJoinUs()
            .navigateToCart()
            .navigateToCheckOut()
            .shipToNewAddress()
            .cashOnDelivery()
            .isOrderPlaced();
        logger.debug(this.getTestEndInfoMessage("HS_02"));
    }

    @Test(groups = {"Hopscotch"},
          description = "HS_03",
          alwaysRun = true)
    public void HS_03() throws Exception {
        logger.debug(this.getTestStartInfoMessage("HS_03"));
        home.splashToHome()
            .moveToAccount()
            .signIn()
            .navigateToSearch()
            .searchProduct()
            .searchListToDesc()
            .addToCart()
            .goBackToHome()
            .moveToCart()
            .navigateToCheckOut()
            .shipToExistingAddress()
            .creditCardPayment();
        logger.debug(this.getTestEndInfoMessage("HS_03"));
    }

    @Test(groups = {"Hopscotch"},
          description = "HS_04",
          alwaysRun = true)
    public void HS_04() throws Exception {
        logger.debug(this.getTestStartInfoMessage("HS_04"));
        home.splashToHome()
            .searchProduct()
            .searchListToDesc()
            .addToCart()
            .goBackToHome()
            .moveToCart()
            .navigateToCheckOut()
            .guestAddAddress()
            .creditDebitCard();
        logger.debug(this.getTestEndInfoMessage("HS_04"));
    }

    @Test(groups = {"Hopscotch"},
          description = "HS_05",
          alwaysRun = true)
    public void HS_05() throws Exception {
        logger.debug(this.getTestStartInfoMessage("HS_05"));
        home.splashToHome()
            .searchProduct()
            .searchListToDesc()
            .addToCart()
            .goBackToHome()
            .moveToCart()
            .navigateToCheckOut()
            .enterMobileNumber()
            .savedCardPayment()
            .isUserLoggedIn();
        logger.debug(this.getTestEndInfoMessage("HS_05"));
    }

    @Test(groups = {"Hopscotch"},
          description = "HS_06",
          alwaysRun = true)
    public void HS_06() throws Exception {
        logger.debug(this.getTestStartInfoMessage("HS_06"));
        home.splashToHome()
            .searchProduct()
            .searchListToDesc()
            .addToCart()
            .goBackToHome()
            .moveToCart()
            .navigateToCheckOut()
            .guestAddAddress()
            .creditDebitCard()
            .cancelOrder()
            .isOrderCancelled();
        logger.debug(this.getTestEndInfoMessage("HS_06"));
    }

    @Test(groups = {"Hopscotch"},
          description = "HS_07",
          alwaysRun = true)
    public void HS_07() throws Exception {
        logger.debug(this.getTestStartInfoMessage("HS_07"));
        home.splashToHome()
            .searchProduct()
            .searchListToDesc()
            .addToCart()
            .goBackToHome()
            .moveToCart()
            .navigateToCheckOut()
            .enterMobileNumber()
            .savedCardPaymentExistingUser();
        logger.debug(this.getTestEndInfoMessage("HS_07"));
    }

    @Test(groups = {"Hopscotch"},
          description = "HS_08",
          alwaysRun = true)
    public void HS_08() throws Exception {
        logger.debug(this.getTestStartInfoMessage("HS_08"));
        home.splashToHome()
            .searchProduct()
            .searchListToDesc()
            .addToCart()
            .goBackToHome()
            .moveToCart()
            .PromoCodeMobileNumber()
            .navigateToCheckOut()
            .shipToNewAddressPromoCode()
            .enterCardDetails()
            .isOrderPlaced();
    }

    @Test(groups = {"Hopscotch"},
          description = "HS_09",
          alwaysRun = true)
    public void HS_09() throws Exception {
        logger.debug(this.getTestStartInfoMessage("HS_09"));
        home.splashToHome()
            .moveToAccount()
            .signIn()
            .navigateToSearch()
            .searchProduct()
            .searchListToDesc()
            .addToCart()
            .goBackToHome()
            .moveToCart()
            .enterPromoCode()
            .navigateToCheckOut()
            .promoCodeCOD()
            .isOrderPlaced();
        logger.debug(this.getTestEndInfoMessage("HS_09"));
    }

    @Test(groups = {"Hopscotch", "test"},
          description = "HS_11",
          alwaysRun = true)
    public void HS_11() throws Exception {
        logger.debug(this.getTestStartInfoMessage("HS_11"));
        home.splashToHome()
            .searchProduct()
            .searchListToDesc()
            .addToCart()
            .goBackToHome()
            .moveToAccount()
            .navigateToCart()
            .navigateToCheckOut()
            .guestAddAddress()
            .cancelOnReviewPage()
            .incrementQuantity()
            .creditCardPayment();
        logger.debug(this.getTestEndInfoMessage("HS_11"));
    }

    @Test(groups = {"Hopscotch", "test"},
          description = "HS_12",
          alwaysRun = true)
    public void HS_12() throws Exception {
        logger.debug(this.getTestStartInfoMessage("HS_12"));
        home.splashToHome()
            .searchProduct()
            .searchListToDesc()
            .addToCart()
            .goBackToHome()
            .moveToAccount()
            .signIn()
            .navigateToCart()
            .updateCart()
            .navigateToCheckOut()
            .shipToExistingAddress()
            .creditDebitCard()
            .isCartEmpty()
            .shopNowForNextRun()
            .searchProduct()
            .searchListToDesc()
            .addToCart();
        logger.debug(this.getTestEndInfoMessage("HS_12"));
    }

    @Test(groups = {"Hopscotch", "test"},
          description = "HS_13",
          alwaysRun = true)
    public void HS_13() throws Exception {
        logger.debug(this.getTestStartInfoMessage("HS_13"));
        home.splashToHome()
            .searchProduct()
            .searchListToDesc()
            .addToCart()
            .goBackToHome()
            .moveToAccount()
            .signIn()
            .navigateToCart()
            .notNowInCart()
            .navigateToCheckOut()
            .shipToExistingAddress()
            .creditDebitCard()
            .isProductPresent();
        logger.debug(this.getTestEndInfoMessage("HS_13"));

    }

    @Test(groups = {"Hopscotch"},
          description = "HS_14",
          alwaysRun = true)
    public void HS_14() throws Exception {
        logger.debug(this.getTestStartInfoMessage("HS_14"));
        home.splashToHome()
            .searchProduct()
            .isAbleToScroll();
        logger.debug(this.getTestEndInfoMessage("HS_14"));
    }

    @Test(groups = {"Hopscotch"},
          description = "HS_15",
          alwaysRun = true)
    public void HS_15() throws Exception {
        logger.debug(this.getTestStartInfoMessage("HS_15"));
        home.splashToHome()
            .moveToBoutique()
            .swipeTillLastProduct()
            .selectLastProduct()
            .isProductImageDetailsDisplayed();
        logger.debug(this.getTestEndInfoMessage("HS_15"));
    }

    @Test(groups = {"Hopscotch"},
          description = "HS_16",
          alwaysRun = true)
    public void HS_16() throws Exception {
        logger.debug(this.getTestStartInfoMessage("HS_16"));
        home.splashToHome()
            .moveToBoutique()
            .boutiqueListToDesc()
            .multipleItemsAddToCart()
            .isMultipleProductsAdded();
        logger.debug(this.getTestEndInfoMessage("HS_16"));
    }

    @Test(groups = {"Hopscotch"},
          description = "HS_17",
          alwaysRun = true)
    public void HS_17() throws Exception {
        logger.debug(this.getTestStartInfoMessage("HS_17"));
        home.splashToHome()
            .moveToBoutique()
            .boutiqueListToDesc()
            .validatePincode();
        logger.debug(this.getTestEndInfoMessage("HS_17"));
    }

    @Test(groups = {"Hopscotch"},
          description = "HS_18",
          alwaysRun = true)
    public void HS_18() throws Exception {
        logger.debug(this.getTestStartInfoMessage("HS_18"));
        home.splashToHome()
            .moveToAccount()
            .signIn()
            .clearCart()
            .navigateToSearch()
            .searchProduct()
            .searchListToDesc()
            .addToCart()
            .goBackToHome()
            .moveToCart()
            .navigateToCheckOut()
            .existingAddressInvalidCard()
            .invalidCreditDebitCard()
            .orderPaymentFailed();
        logger.debug(this.getTestEndInfoMessage("HS_18"));
    }

    @Test(groups = {"Hopscotch"},
          description = "HS_19",
          alwaysRun = true)
    public void HS_19() throws Exception {
        logger.debug(this.getTestStartInfoMessage("HS_19"));
        home.splashToHome()
            .navigateToMoments()
            .imageMoments();
        logger.debug(this.getTestEndInfoMessage("HS_19"));
    }

    @Test(groups = {"Hopscotch"},
          description = "HS_20",
          alwaysRun = true)
    public void HS_20() throws Exception {
        logger.debug(this.getTestStartInfoMessage("HS_20"));
        home.splashToHome()
            .navigateToBoutique()
            .verifyBoutique();
        logger.debug(this.getTestEndInfoMessage("HS_20"));
    }

    @Test(groups = {"Hopscotch"},
            description = "HS_21",
            alwaysRun = true)
    public void HS_21() throws Exception {
        logger.debug(this.getTestStartInfoMessage("HS_21"));
        home.splashToHome()
            .searchProduct()
            .searchListToDesc()
            .addToCart()
            .goBackToHome()
            .moveToCart()
            .navigateToCheckOut()
            .newMobileNumber()
            .newAddressExistingMailID()
            .signInFromAccount()
            .navigateToCart()
            .navigateToCheckOut()
            .shipToExistingAddress()
            .cashOnDelivery()
            .isOrderPlaced();
        logger.debug(this.getTestEndInfoMessage("HS_21"));
    }

    @Test(groups = {"Hopscotch"},
          description = "HS_22",
          alwaysRun = true)
    public void HS_22() throws Exception {
        logger.debug(this.getTestStartInfoMessage("HS_22"));
        home.splashToHome()
            .moveToAccount()
            .signIn()
            .profileDetailsSignIn()
            .editProfileName();
        logger.debug(this.getTestEndInfoMessage("HS_22"));
    }

    @Test(groups = {"Hopscotch"},
          description = "HS_24",
          alwaysRun = true)
    public void HS_24() throws Exception {
        logger.debug(this.getTestStartInfoMessage("HS_24"));
        home.splashToHome()
            .searchProduct()
            .applyAllFilter();
        logger.debug(this.getTestEndInfoMessage("HS_24"));
    }

    @Test(groups = {"Hopscotch"},
          description = "HS_26",
          alwaysRun = true)
    public void HS_26() throws Exception {
        logger.debug(this.getTestStartInfoMessage("HS_26"));
        home.splashToHome()
            .scrollDownHomePage()
            .closeAndRelaunch()
            .verifyAppRelaunched();
        logger.debug(this.getTestEndInfoMessage("HS_26"));
    }

    @Test(groups = {"Hopscotch"},
          description = "HS_28",
          alwaysRun = true)
    public void HS_28() throws Exception {
        logger.debug(this.getTestStartInfoMessage("HS_28"));
        home.splashToHome()
            .moveToBoutique()
            .boutiqueListToDesc()
            .viewSimilarProducts()
            .isSimilarProductDisplayed();
        logger.debug(this.getTestEndInfoMessage("HS_28"));
    }
}