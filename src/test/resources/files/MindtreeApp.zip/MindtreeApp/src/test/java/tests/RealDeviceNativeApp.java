package tests;

import org.testng.annotations.Test;
import org.testng.annotations.Test;

public class RealDeviceNativeApp extends SupportTest {

	@Test
	public void nativeappTest() throws Exception {

		logger.debug(this.getTestStartInfoMessage("nativeappTest"));
		rdna.appFlow();
		logger.debug(this.getTestEndInfoMessage("nativeappTest"));

	}

}
