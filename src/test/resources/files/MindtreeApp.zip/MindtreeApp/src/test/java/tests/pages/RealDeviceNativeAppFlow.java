package tests.pages;

import java.util.Map;

import org.openqa.selenium.Keys;

import agent.IAgent;
import central.Configuration;

public class RealDeviceNativeAppFlow extends FullPage {

	public RealDeviceNativeAppFlow(Configuration conf, IAgent agent, Map<String, String> testData) throws Exception {
		super(conf, agent, testData);
		assertPageLoad();
	}
	public void appFlow() throws Exception {
		logger.debug(String.format("(%s) Logging in...", this.getPlatform()));
		switch (this.getPlatform()) {
		case IOS:
			break;
		case IOS_WEB:
			break;
		case ANDROID:
			enterText(this.getTestData());
			Thread.sleep(3000);
		
			
			
			
		break;
		case ANDROID_WEB:
			break;
		case DESKTOP_WEB:
		}
	}

	private void enterText(Map<String, String> testData) throws Exception {
	for(int i=470;i<=500;i+=5) {
		getControl("firstTextbox").enterText(String.valueOf(i));
		getControl("secondtext").enterText(String.valueOf(++i));
		getControl("btnMulyiply").click();
		String rst = getControl("result").getText();
		logger.info(String.format("result is = %s", rst));
		getControl("firstTextbox").clear();
		getControl("secondtext").clear();
	}
	}
	
	

}
