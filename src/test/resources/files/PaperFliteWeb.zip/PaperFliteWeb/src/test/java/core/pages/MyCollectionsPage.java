package core.pages;

import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import agent.IAgent;
import central.Configuration;

public class MyCollectionsPage extends FullPage {

	public MyCollectionsPage(Configuration conf, IAgent agent, Map<String, String> testData) throws Exception {
		super(conf, agent, testData);
		assertPageLoad();
	}

	String osName=System.getProperty("os.name").toLowerCase();
	
	public HomePage myCollections() throws Exception {
		logger.debug(String.format("(%s) Logging in...", this.getPlatform()));
			getControl("createCollection").click();
			getControl("addCollection").enterText("App "+generateString(5));
			getControl("btnSave").click();
			getControl("addAsset").click();
			getControl("btnAddStreams").click();
			getControl("collection1").click();
			
			for(int i=3;i<=6;i++) {
				driver.findElement(By.xpath("(//*[contains(text(),'sample')])["+i+"]")).click();
			}
			Thread.sleep(5000);
			getControl("saveCollection").click();
			if(osName.contains("mac os") || osName.contains("macos") || osName.contains("darwin")) {
				getControl("uploadBackground").uploadFile(System.getProperty("user.dir")+"/Images/Image.jpg" );
			}else {
				getControl("uploadBackground").uploadFile(System.getProperty("user.dir")+"\\Images\\Image.jpg" );
			}
			getControl("btnUpload").click();
			getControl("btnSaveChange").click();
			getControl("btnCollaborate").click();
			getControl("btnUserradio").click();
			getControl("btnSave").click();
			Thread.sleep(5000);
			getControl("btnShare").click();
			Thread.sleep(3000);
			getControl("txtTo").enterText(this.getTestData().get("To"));
			getControl("txtSubject").enterText(this.getTestData().get("Subject"));
			getControl("btnSend").click();
			Thread.sleep(5000);
			takeSnapShot();
			Thread.sleep(10000);
			
			((JavascriptExecutor)driver).executeScript("window.open();");
			switchToNewWindow();
			driver.manage().timeouts().pageLoadTimeout(10, TimeUnit.SECONDS);
			driver.get("https://gmail.com");
			driver.manage().timeouts().pageLoadTimeout(10, TimeUnit.SECONDS);
			getControl("gmailid").enterText(this.getTestData().get("gmailid"));
			getControl("gmailnextbutton").click();
			getControl("gmailpassword").enterText(this.getTestData().get("gmailpassword"));
			getControl("gmailnextbutton").click();
			driver.manage().timeouts().pageLoadTimeout(10, TimeUnit.SECONDS);
			List<WebElement> a = driver.findElements(By.xpath("//*[@class='bog']/span"));
			for(int i=0;i<a.size();i++){
				System.out.println(a.get(i).getText());
				if(a.get(i).getText().equals("Appachhi Testing")){ 
					a.get(i).click();
					break;
				}
			}
			Thread.sleep(5000);
			getControl("tabMailList").click();
			getControl("linkAsset").click();
			Thread.sleep(5000);
			Set<String> s = driver.getWindowHandles();
			for(String nw:s) {
				String pageTitle=driver.switchTo().window(nw).getTitle();
				if(pageTitle.contains("Check out your new Home")) {
					driver.manage().timeouts().pageLoadTimeout(10, TimeUnit.SECONDS);
					takeSnapShot();
					Thread.sleep(15000);
					takeSnapShot();
					scrollUp();
					takeSnapShot();
					scrollUp(5);
					driver.close();
					break;
				}
			}
			
			Thread.sleep(5000);
			switchToMainWindow();
			Thread.sleep(5000);
			getControl("linkHome").click();
			return new HomePage(getConfig(), getAgent(), getTestData());
	}
}



