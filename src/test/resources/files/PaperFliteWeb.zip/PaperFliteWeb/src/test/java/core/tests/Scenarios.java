package core.tests;

import org.testng.annotations.Test;

public class Scenarios extends SupportTest {

	@Test
	public void PaperFliteFlow() throws Exception {
		logger.debug(this.getTestStartInfoMessage("SignInTest"));
		lp.Login().clickCollections().myCollections().checkNotifications();
		logger.debug(this.getTestEndInfoMessage("SignInTest"));

	}
}
