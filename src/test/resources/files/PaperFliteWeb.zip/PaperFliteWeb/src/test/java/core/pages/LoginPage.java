package core.pages;

import java.util.Map;

import org.openqa.selenium.Keys;

import agent.IAgent;
import central.Configuration;

public class LoginPage extends FullPage {

	public LoginPage(Configuration conf, IAgent agent, Map<String, String> testData) throws Exception {
		super(conf, agent, testData);
		assertPageLoad();
	}
	public HomePage Login() throws Exception {
		logger.debug(String.format("(%s) Logging in...", this.getPlatform()));
			switchToDefaultFrame();
			getControl("linkLogin").click();
			enterLoginCredentials(this.getTestData());
			return new HomePage(getConfig(), getAgent(), getTestData());
		}


	private void enterLoginCredentials(Map<String, String> testData) throws Exception {
		getControl("username").enterText(testData.get("username"));
		getControl("password").enterText(testData.get("password"));
		getControl("btnSignIn").click();
	}

}
