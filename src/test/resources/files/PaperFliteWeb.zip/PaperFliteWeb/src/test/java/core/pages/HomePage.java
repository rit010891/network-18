package core.pages;

import java.util.Map;

import org.openqa.selenium.Keys;

import agent.IAgent;
import central.Configuration;

public class HomePage extends FullPage {

	public HomePage(Configuration conf, IAgent agent, Map<String, String> testData) throws Exception {
		super(conf, agent, testData);
		assertPageLoad();
	}
	public MyCollectionsPage clickCollections() throws Exception {
		logger.debug(String.format("(%s) Logging in...", this.getPlatform()));
		getControl("linkCollections").click();
		return new MyCollectionsPage(getConfig(), getAgent(), getTestData());
		}

    public void assertPageLoad() throws Exception {
        super.assertPageLoad();
        getControl("txtHome").assertVisible();
    }
    
    public void checkNotifications() throws Exception {
    	logger.debug(String.format("(%s) Logging in...", this.getPlatform()));
    	getControl("linkNotification").click();
    	Thread.sleep(10000);
    	scrollDown();
    	takeSnapShot();
    	scrollDown(3);
    }
}


